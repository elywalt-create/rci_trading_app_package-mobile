# RCI Trading App - Package (React Native + Node backend)
This package contains a ready-to-build scaffold for an Android app (React Native) and a Node.js backend.
Use this to compile an APK for Android and run the backend (optional).

**Contents**
- mobile/ : React Native app scaffold (App.js, package.json, example screens)
- backend/: Node.js Express backend scaffold (adapters for Binance & IB example)
- .github/workflows/build_apk.yml : GitHub Actions workflow to build APK automatically
- build_apk.sh : helper script to build APK locally (requires environment setup)

**Notes**
- This is a scaffold to get you started. You will still need to build the APK (the workflow automates this).
- Do NOT commit your real API keys to source control. The app uses secure storage (Android Keystore recommended).
- For Interactive Brokers integration you will need IB Gateway/TWS credentials and setup; instructions are in backend/README.md.
