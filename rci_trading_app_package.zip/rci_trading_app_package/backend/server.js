const express = require('express');
const bodyParser = require('body-parser');
const yf = require('yahoo-finance2').default;
const app = express();
app.use(bodyParser.json());

// Simple RCI calculation (approximation using ranks)
function rci(close, period) {
  const out = Array(close.length).fill(null);
  for (let i = period-1; i < close.length; i++) {
    const win = close.slice(i-period+1, i+1);
    // ranks
    const priceRanks = win.map((v, idx)=> ({v, idx})).sort((a,b)=> a.v - b.v).map((x,i)=> ({idx:x.idx, r:i+1}));
    const rPrice = Array(win.length);
    priceRanks.forEach(p=> rPrice[p.idx]=p.r);
    const rTime = [...Array(win.length)].map((_,i)=> i+1);
    // pearson corr between rPrice and rTime
    const mean = arr => arr.reduce((s,a)=>s+a,0)/arr.length;
    const mr = mean(rPrice), mt = mean(rTime);
    let num=0, den1=0, den2=0;
    for(let j=0;j<win.length;j++){ const a=rPrice[j]-mr, b=rTime[j]-mt; num+=a*b; den1+=a*a; den2+=b*b; }
    const rho = num/Math.sqrt(den1*den2);
    out[i] = rho*100;
  }
  return out;
}

app.post('/api/backtest', async (req, res)=>{
  try{
    const {ticker, start} = req.body;
    const q = await yf.historical(ticker, { period1: start });
    if(!q || q.length===0) return res.status(400).json({error:'Sem dados'});
    const close = q.map(x=> x.close);
    const rciSeries = rci(close, 14);
    // simple signal based on -80/+80 crossings
    const signals = [];
    for(let i=1;i<rciSeries.length;i++){
      const prev = rciSeries[i-1]||0, cur = rciSeries[i]||0;
      if(prev < -80 && cur >= -80) signals.push({date:q[i].date, type:'BUY'});
      else if(prev > 80 && cur <= 80) signals.push({date:q[i].date, type:'SELL'});
    }
    return res.json({summary:{signals:signals.length, lastSignal: signals.slice(-1)[0]||null}});
  }catch(e){
    return res.status(500).json({error:e.message});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Backend rodando na porta', PORT));
