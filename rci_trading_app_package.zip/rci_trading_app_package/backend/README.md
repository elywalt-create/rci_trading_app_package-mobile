## Backend - RCI Trading (Node.js)
- Simple Express server that downloads historical data via `yahoo-finance2` and computes RCI.
- This backend is a starting point. For real integration with Binance or IB, adapters must be added.

### Run
cd backend
npm install
npm start
