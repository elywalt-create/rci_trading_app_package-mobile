import React, {useState} from 'react';
import {SafeAreaView, View, Text, TextInput, Button, StyleSheet, Alert} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

export default function App() {
  const [ticker, setTicker] = useState('BTCUSDT');
  const [start, setStart] = useState('2023-01-01');
  const [cash, setCash] = useState('100000');

  const runBacktest = async () => {
    try {
      const res = await axios.post('http://10.0.2.2:3000/api/backtest', {
        ticker, start, cash
      });
      Alert.alert('Backtest pronto', JSON.stringify(res.data.summary));
    } catch (e) {
      Alert.alert('Erro', e.message);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>RCI Trading - Demo</Text>
      <View style={styles.field}>
        <Text>Ticker</Text>
        <TextInput style={styles.input} value={ticker} onChangeText={setTicker} />
      </View>
      <View style={styles.field}>
        <Text>Start (YYYY-MM-DD)</Text>
        <TextInput style={styles.input} value={start} onChangeText={setStart} />
      </View>
      <View style={styles.field}>
        <Text>Capital</Text>
        <TextInput style={styles.input} value={cash} onChangeText={setCash} keyboardType='numeric' />
      </View>
      <Button title='Rodar Backtest (mobile->backend)' onPress={runBacktest} />
      <Text style={{marginTop:20, fontSize:12, color:'#666'}}>Conectar chaves e operar real via menu (em desenvolvimento)</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {flex:1, padding:16, backgroundColor:'#fff'},
  title: {fontSize:20, fontWeight:'bold', marginBottom:12},
  field: {marginBottom:10},
  input: {borderWidth:1, borderColor:'#ccc', padding:8, borderRadius:6}
});
