## Mobile app (React Native) - Notes
- This is a minimal UI that calls the backend for heavy tasks (backtest, paper trading simulation).
- To build locally (recommended using macOS/Windows + Android SDK or GitHub Actions):
  1. Install Node.js, Java JDK, Android SDK & React Native CLI
  2. cd mobile
  3. npm install
  4. npx react-native run-android
- In development, backend is expected at http://10.0.2.2:3000 (Android emulator host).
