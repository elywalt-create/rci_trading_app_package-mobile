#!/bin/bash
echo "This script outlines local build steps. You must have Android SDK and React Native configured."
echo "1) cd mobile && npm install"
echo "2) npx react-native run-android  # or use Android Studio to build an APK"
